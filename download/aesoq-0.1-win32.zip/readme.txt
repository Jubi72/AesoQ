﻿Mit dem Programm AesoQ (lat. aequationes quadratas solvere - quadratische Gleichungen lösen) kann man eine quadratische Gleichung lösen lassen.
Dafür muss die Gleichung vorher manuell in die Form 0 = ax² + bx + c gebracht werden.

Danach muss die Zahl a in das Feld a eingegeben werden - als Fließkommazahl mit Punkt statt Komma, also beispielsweise eine Zahl im Format 3.5 . Sollte a = 1 sein, kann man das Feld a auch leer lassen.
Genauso verfährt man mit den Variablen b und c. Sollte a = 1 sein, werden die Felder nachfolgend nicht mehr b, sondern p und q anstelle von c genannt. -> 0 = x² + px + q
Dann muss in das Feld runden noch eine Zahl eingegeben werden, auf wie viele Stellen das Ergebnis gerundet werden soll.

Diese Datei findet man auch als Text in der Hilfe über die Menüleiste. Eine Information zum Programm findet man im Punkt "Über" im Menü Hilfe.
Man kann das Fenster entweder über das Schließkreuz oder über das Feld schließen im Menü Datei schließen.

Bei Fragen zum Programm kontaktieren Sie bitte den Entwickler über GitHub (Jubi72/AesoQ) oder über die E-Mail-Adresse content.legoag@gmail.com .

Copyríght Julius Bittner 2015 - CC-BY 3.0 - Letzte Änderung 05.01.2015 - Zeichenkodierung: UTF-8